package StudentData;
public class Student {
    public static void main(String[] args) {
        Log_in x = new Log_in();
        x.setVisible(true);
    }
    
}
