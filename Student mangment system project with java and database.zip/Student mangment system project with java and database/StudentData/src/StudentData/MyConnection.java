package StudentData;


import java.sql.*;

public class MyConnection {
    public Connection connection=null;
    public Connection getconConnection(){
        System.out.print("mysql Connection Testing\n");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection=DriverManager.getConnection("jdbc:mysql://localhost/java?UseUnicode=yes&characterEncoding=UTF-8","mahmoud","MahmoudEssam");
            System.out.println("Driver Registered\n");
            if (connection !=null){
                System.out.println("You Made It");}
            else{
                System.out.println("Failed");}
        }
        catch(ClassNotFoundException ex){
            System.out.println("Where is MySql Driver");
            ex.printStackTrace();
        }
        catch(SQLException e)
        {
            System.out.println("Connection Failed");
            e.printStackTrace();
        }
        return connection;
    }
    
}



